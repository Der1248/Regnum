



level1 = 10
level1_drop = "tutorial:coin 1"
	 
level1S = 10
level1S_drop = "tutorial:level1 1"
	
	 
level2 = 20
level2_drop = "tutorial:coin 1"

level2S = 20
level2S_drop = "tutorial:level2 1"


level3 = 30
level3_drop = "tutorial:coin 1"

level3S = 30
level3S_drop = "tutorial:level3 1"


level4 = 40
level4_drop = "tutorial:coin 1"

level4S = 40
level4S_drop = "tutorial:level4 1"


level5 = 50
level5_drop = "tutorial:coin 1"

level5S = 50
level5S_drop = "tutorial:level5 1"


level6 = 70 
level6_drop = "tutorial:coin 2"

level6S = 70
level6S_drop = "tutorial:level6 1"


level7 = 90
level7_drop = "tutorial:coin 2"

level7S = 90
level7S_drop = "tutorial:level7 1"


level8 = 110
level8_drop = "tutorial:coin 2"

level8S = 110
level8S_drop = "tutorial:level8 1"


level9 = 130
level9_drop = "tutorial:coin 2"

level9S = 130
level9S_drop = "tutorial:level9 1"


level10 = 150
level10_drop = "tutorial:coin 2"

level10S = 150
level10S_drop = "tutorial:level10 1"


level11 = 180
level11_drop = "tutorial:coin 3"

level11S = 180
level11S_drop = "tutorial:level11 1"


level12 = 210
level12_drop = "tutorial:coin 3"

level12S = 210
level12S_drop = "tutorial:level12 1"


level13 = 240
level13_drop = "tutorial:coin 3"

level13S = 240
level13S_drop = "tutorial:level13 1"


level14 = 270
level14_drop = "tutorial:coin 3"

level14S = 270
level14S_drop = "tutorial:level14 1"


level15 = 300
level15_drop = "tutorial:coin 3"

level15S = 300
level15S_drop = "tutorial:level15 1"


level16 = 340
level16_drop = "tutorial:coin 4"

level16S = 340
level16S_drop = "tutorial:level16 1"


level17 = 380
level17_drop = "tutorial:coin 4"

level17S = 380
level17S_drop = "tutorial:level17 1"


level18 = 420
level18_drop = "tutorial:coin 4"

level18S = 420
level18S_drop = "tutorial:level18 1"


level19 = 460
level19_drop = "tutorial:coin 4"

level19S = 460
level19S_drop = "tutorial:level19 1"


level20 = 500
level20_drop = "tutorial:coin 4"

level20S = 500
level20S_drop = "tutorial:level20 1"


level21 = 550
level21_drop = "tutorial:coin 5"

level21S = 550
level21S_drop = "tutorial:level21 1"


level22 = 600
level22_drop = "tutorial:coin 5"

level22S = 600
level22S_drop = "tutorial:level22 1"


level23 = 650
level23_drop = "tutorial:coin 5"

level23S = 650
level23S_drop = "tutorial:level23 1"


level24 = 700
level24_drop = "tutorial:coin 5"

level24S = 700
level24S_drop = "tutorial:level24 1"


level25 = 750
level25_drop = "tutorial:coin 5"

level25S = 750
level25S_drop = "tutorial:level25 1"


level26 = 810
level26_drop = "tutorial:coin 6"

level26S = 810
level26S_drop = "tutorial:level26 1"


level27 = 870
level27_drop = "tutorial:coin 6"

level27S = 870
level27S_drop = "tutorial:level27 1"


level28 = 930
level28_drop = "tutorial:coin 6"

level28S = 930
level28S_drop = "tutorial:level28 1"


level29 = 990
level29_drop = "tutorial:coin 6"

level29S = 990
level29S_drop = "tutorial:level29 1"


level30 = 1050
level30_drop = "tutorial:coin 6"

level30S = 1050
level30S_drop = "tutorial:level30 1"


level31 = 1120
level31_drop = "tutorial:coin 7"

level31S = 1120
level31S_drop = "tutorial:level31 1"


level32 = 1190
level32_drop = "tutorial:coin 7"

level32S = 1190
level32S_drop = "tutorial:level32 1"


level33 = 1260
level33_drop = "tutorial:coin 7"

level33S = 1260
level33S_drop = "tutorial:level33 1"


level34 = 1330
level34_drop = "tutorial:coin 7"

level34S = 1330
level34S_drop = "tutorial:level34 1"


level35 = 1400
level35_drop = "tutorial:coin 7"

level35S = 1400
level35S_drop = "tutorial:level35 1"








level36 = 1480
level36_drop = "tutorial:coin 8"

level36S = 1480
level36S_drop = "tutorial:level36 1"


level37 = 1560
level37_drop = "tutorial:coin 8"

level37S = 1560
level37S_drop = "tutorial:level37 1"


level38 = 1640
level38_drop = "tutorial:coin 8"

level38S = 1640
level38S_drop = "tutorial:level38 1"


level39 = 1720
level39_drop = "tutorial:coin 8"

level39S = 1720
level39S_drop = "tutorial:level39 1"


level40 = 1800
level40_drop = "tutorial:coin 8"

level40S = 1800
level40S_drop = "tutorial:level40 1"


level41 = 1890
level41_drop = "tutorial:coin 9"

level41S = 1890
level41S_drop = "tutorial:level41 1"


level42 = 1980
level42_drop = "tutorial:coin 9"

level42S = 1980
level42S_drop = "tutorial:level42 1"


level43 = 2070
level43_drop = "tutorial:coin 9"

level43S = 2070
level43S_drop = "tutorial:level43 1"


level44 = 2160
level44_drop = "tutorial:coin 9"

level44S = 2160
level44S_drop = "tutorial:level44 1"


level45 = 2250
level45_drop = "tutorial:coin 9"

level45S = 2250
level45S_drop = "tutorial:level45 1"


level46 = 2350
level46_drop = "tutorial:coin 10"

level46S = 2350
level46S_drop = "tutorial:level46 1"


level47 = 2450
level47_drop = "tutorial:coin 10"

level47S = 2450
level47S_drop = "tutorial:level47 1"


level48 = 2550
level48_drop = "tutorial:coin 10"

level48S = 2550
level48S_drop = "tutorial:level48 1"


level49 = 2650
level49_drop = "tutorial:coin 10"

level49S = 2650
level49S_drop = "tutorial:level49 1"


level50 = 2750
level50_drop = "tutorial:coin 10"

level50S = 2750
level50S_drop = "tutorial:level50 1"

level50SS = 2750
level50SS_drop = "tutorial:level_schluessel 1"






level51 = 2860
level51_drop = "tutorial:coin 11"

level51S = 2860
level51S_drop = "tutorial:level51 1"


level52 = 2970
level52_drop = "tutorial:coin 11"

level52S = 2970
level52S_drop = "tutorial:level52 1"


level53 = 3080
level53_drop = "tutorial:coin 11"

level53S = 3080
level53S_drop = "tutorial:level53 1"


level54 = 3190
level54_drop = "tutorial:coin 11"

level54S = 3190
level54S_drop = "tutorial:level54 1"


level55 = 3300
level55_drop = "tutorial:coin 11"

level55S = 3300
level55S_drop = "tutorial:level55 1"

level56 = 3420
level56_drop = "tutorial:coin 12"

level56S = 3420
level56S_drop = "tutorial:level56 1"


level57 = 3540
level57_drop = "tutorial:coin 12"

level57S = 3540
level57S_drop = "tutorial:level57 1"



level58 = 3660
level58_drop = "tutorial:coin 12"

level58S = 3660
level58S_drop = "tutorial:level58 1"



level59 = 3780
level59_drop = "tutorial:coin 12"

level59S = 3780
level59S_drop = "tutorial:level59 1"


level60 = 3900
level60_drop = "tutorial:coin 12"

level60S = 3900
level60S_drop = "tutorial:level60 1"



level61 = 4030
level61_drop = "tutorial:coin 13"

level61S = 4030
level61S_drop = "tutorial:level61 1"



level62 = 4160
level62_drop = "tutorial:coin 13"

level62S = 4160
level62S_drop = "tutorial:level62 1"



level63 = 4290
level63_drop = "tutorial:coin 13"

level63S = 4290
level63S_drop = "tutorial:level63 1"



level64 = 4420
level64_drop = "tutorial:coin 13"

level64S = 4420
level64S_drop = "tutorial:level64 1"



level65 = 4550
level65_drop = "tutorial:coin 13"

level65S = 4550
level65S_drop = "tutorial:level65 1"



level66 = 4690
level66_drop = "tutorial:coin 14"

level66S = 4690
level66S_drop = "tutorial:level66 1"



level67 = 4830
level67_drop = "tutorial:coin 14"

level67S = 4830
level67S_drop = "tutorial:level67 1"



level68 = 4970
level68_drop = "tutorial:coin 14"

level68S = 4970
level68S_drop = "tutorial:level68 1"



level69 = 5110
level69_drop = "tutorial:coin 14"

level69S = 5110
level69S_drop = "tutorial:level69 1"



level70 = 5250
level70_drop = "tutorial:coin 14"

level70S = 5250
level70S_drop = "tutorial:level70 1"


level71 = 5400
level71_drop = "tutorial:coin 15"

level71S = 5400
level71S_drop = "tutorial:level71 1"


level72 = 5550
level72_drop = "tutorial:coin 15"

level72S = 5550
level72S_drop = "tutorial:level72 1"


level73 = 5700
level73_drop = "tutorial:coin 15"

level73S = 5700
level73S_drop = "tutorial:level73 1"


level74 = 5850
level74_drop = "tutorial:coin 15"

level74S = 5850
level74S_drop = "tutorial:level74 1"


level75 = 6000
level75_drop = "tutorial:coin 15"

level75S = 6000
level75S_drop = "tutorial:level75 1"


level76 = 6160
level76_drop = "tutorial:coin 16"

level76S = 6160
level76S_drop = "tutorial:level76 1"


level77 = 6320
level77_drop = "tutorial:coin 16"

level77S = 6320
level77S_drop = "tutorial:level77 1"


level78 = 6480
level78_drop = "tutorial:coin 16"

level78S = 6480
level78S_drop = "tutorial:level78 1"


level79 = 6640
level79_drop = "tutorial:coin 16"

level79S = 6640
level79S_drop = "tutorial:level79 1"


level80 = 6800
level80_drop = "tutorial:coin 16"

level80S = 6800
level80S_drop = "tutorial:level80 1"



level81 = 6970
level81_drop = "tutorial:coin 17"

level81S = 6970
level81S_drop = "tutorial:level81 1"


level82 = 7140
level82_drop = "tutorial:coin 17"

level82S = 7140
level82S_drop = "tutorial:level82 1"


level83 = 7310
level83_drop = "tutorial:coin 17"

level83S = 7310
level83S_drop = "tutorial:level83 1"


level84 = 7480
level84_drop = "tutorial:coin 17"

level84S = 7480
level84S_drop = "tutorial:level84 1"


level85 = 7650
level85_drop = "tutorial:coin 17"

level85S = 7650
level85S_drop = "tutorial:level85 1"


level86 = 7830
level86_drop = "tutorial:coin 18"

level86S = 7830
level86S_drop = "tutorial:level86 1"


level87 = 8010
level87_drop = "tutorial:coin 18"

level87S = 8010
level87S_drop = "tutorial:level87 1"


level88 = 8190
level88_drop = "tutorial:coin 18"

level88S = 8190
level88S_drop = "tutorial:level88 1"


level89 = 8370
level89_drop = "tutorial:coin 18"

level89S = 8370
level89S_drop = "tutorial:level89 1"


level90 = 8550
level90_drop = "tutorial:coin 18"

level90S = 8550
level90S_drop = "tutorial:level90 1"


level91 = 8740
level91_drop = "tutorial:coin 19"

level91S = 8740
level91S_drop = "tutorial:level91 1"


level92 = 8930
level92_drop = "tutorial:coin 19"

level92S = 8930
level92S_drop = "tutorial:level92 1"


level93 = 9120
level93_drop = "tutorial:coin 19"

level93S = 9120
level93S_drop = "tutorial:level93 1"


level94 = 9310
level94_drop = "tutorial:coin 19"

level94S = 9310
level94S_drop = "tutorial:level94 1"


level95 = 9500 
level95_drop = "tutorial:coin 19"

level95S = 9500
level95S_drop = "tutorial:level95 1"


level96 = 9700
level96_drop = "tutorial:coin 20"

level96S = 9700
level96S_drop = "tutorial:level96 1"


level97 = 9900
level97_drop = "tutorial:coin 20"

level97S = 9900
level97S_drop = "tutorial:level97 1"


level98 = 10100
level98_drop = "tutorial:coin 20"

level98S = 10100
level98S_drop = "tutorial:level98 1"


level99 = 10300
level99_drop = "tutorial:coin 20"

level99S = 10300
level99S_drop = "tutorial:level99 1"


level100 = 10500
level100_drop = "tutorial:coin 20"

level100S = 10500
level100S_drop = "tutorial:level100 1"

level100SS = 10500
level100SS_drop = "tutorial:lilabattleaxe"


levelMAX = 11950
levelMAX_drop = "tutorial:coin 99"

levelMAXS = 11950
levelMAXS_drop = "tutorial:levelMAX 1"

levelMAXSS = 11950
levelMAXSS_drop = "tutorial:coin 46"
































--add an experience orb if player digs node from xp group
minetest.register_on_dignode(function(pos, oldnode, digger)
	namer = oldnode.name
	see_if_mineral = minetest.get_item_group(namer, "xp")
	if see_if_mineral > 0 then
		minetest.env:add_entity(pos, "experience:orb")
	end
end)
--give a new player some xp
minetest.register_on_newplayer(function(player)
	file = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "w")
	file:write("0")
	file:close()
end)



--Allow people to collect orbs
minetest.register_globalstep(function(dtime)
	for _,player in ipairs(minetest.get_connected_players()) do
		local pos = player:getpos()
		pos.y = pos.y+0.5
		for _,object in ipairs(minetest.env:get_objects_inside_radius(pos, 1)) do
			if not object:is_player() and object:get_luaentity() and object:get_luaentity().name == "experience:orb" then
				--RIGHT HERE ADD IN THE CODE TO UPGRADE PLAYERS 
				object:setvelocity({x=0,y=0,z=0})
				object:get_luaentity().name = "STOP"
				minetest.sound_play("orb", {
					to_player = player:get_player_name(),
				})
				xp = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "r")
				experience = xp:read("*l")
				xp:close()
				if experience ~= nil then
					new_xp = experience + 1
					xp_write = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "w")
					xp_write:write(new_xp)
					xp_write:close()
if new_xp == level1 then
						minetest.env:add_item(pos, level1_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level1S then
						minetest.env:add_item(pos, level1S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level2 then
						minetest.env:add_item(pos, level2_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level2S then
						minetest.env:add_item(pos, level2S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level3 then
						minetest.env:add_item(pos, level3_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level3S then
						minetest.env:add_item(pos, level3S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level4 then
						minetest.env:add_item(pos, level4_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level4S then
						minetest.env:add_item(pos, level4S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level5 then
						minetest.env:add_item(pos, level5_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})       
					end
if new_xp == level5S then
						minetest.env:add_item(pos, level5S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level6 then
						minetest.env:add_item(pos, level6_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level6S then
						minetest.env:add_item(pos, level6S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level7 then
						minetest.env:add_item(pos, level7_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level7S then
						minetest.env:add_item(pos, level7S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level8 then
						minetest.env:add_item(pos, level8_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level8S then
						minetest.env:add_item(pos, level8S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level9 then
						minetest.env:add_item(pos, level9_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level9S then
						minetest.env:add_item(pos, level9S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level10 then
						minetest.env:add_item(pos, level10_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level10S then
						minetest.env:add_item(pos, level10S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level11 then
						minetest.env:add_item(pos, level11_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level11S then
						minetest.env:add_item(pos, level11S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level12 then
						minetest.env:add_item(pos, level12_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level12S then
						minetest.env:add_item(pos, level12S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level13 then
						minetest.env:add_item(pos, level13_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level13S then
						minetest.env:add_item(pos, level13S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level14 then
						minetest.env:add_item(pos, level14_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level14S then
						minetest.env:add_item(pos, level14S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level15 then
						minetest.env:add_item(pos, level15_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level15S then
						minetest.env:add_item(pos, level15S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level16 then
						minetest.env:add_item(pos, level16_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level16S then
						minetest.env:add_item(pos, level16S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level17 then
						minetest.env:add_item(pos, level17_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level17S then
						minetest.env:add_item(pos, level17S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level18 then
						minetest.env:add_item(pos, level18_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level18S then
						minetest.env:add_item(pos, level18S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					
if new_xp == level19 then
						minetest.env:add_item(pos, level19_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level19S then
						minetest.env:add_item(pos, level19S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level20 then
						minetest.env:add_item(pos, level20_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level20S then
						minetest.env:add_item(pos, level20S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level21 then
						minetest.env:add_item(pos, level21_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level21S then
						minetest.env:add_item(pos, level21S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level22 then
						minetest.env:add_item(pos, level22_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level22S then
						minetest.env:add_item(pos, level22S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level23 then
						minetest.env:add_item(pos, level23_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level23S then
						minetest.env:add_item(pos, level23S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level24 then
						minetest.env:add_item(pos, level24_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level24S then
						minetest.env:add_item(pos, level24S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level25 then
						minetest.env:add_item(pos, level25_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level25S then
						minetest.env:add_item(pos, level25S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level26 then
						minetest.env:add_item(pos, level26_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level26S then
						minetest.env:add_item(pos, level26S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level27 then
						minetest.env:add_item(pos, level27_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level27S then
						minetest.env:add_item(pos, level27S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level28 then
						minetest.env:add_item(pos, level28_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level28S then
						minetest.env:add_item(pos, level28S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level29 then
						minetest.env:add_item(pos, level29_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level29S then
						minetest.env:add_item(pos, level29S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level30 then
						minetest.env:add_item(pos, level30_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level30S then
						minetest.env:add_item(pos, level30S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end






if new_xp == level31 then
						minetest.env:add_item(pos, level31_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level31S then
						minetest.env:add_item(pos, level31S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level32 then
						minetest.env:add_item(pos, level32_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level32S then
						minetest.env:add_item(pos, level32S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level33 then
						minetest.env:add_item(pos, level33_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level33S then
						minetest.env:add_item(pos, level33S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level34 then
						minetest.env:add_item(pos, level34_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level34S then
						minetest.env:add_item(pos, level34S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level35 then
						minetest.env:add_item(pos, level35_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level35S then
						minetest.env:add_item(pos, level35S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level36 then
						minetest.env:add_item(pos, level36_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level36S then
						minetest.env:add_item(pos, level36S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level37 then
						minetest.env:add_item(pos, level37_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level37S then
						minetest.env:add_item(pos, level37S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level38 then
						minetest.env:add_item(pos, level38_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level38S then
						minetest.env:add_item(pos, level38S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level39 then
						minetest.env:add_item(pos, level39_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level39S then
						minetest.env:add_item(pos, level39S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level40 then
						minetest.env:add_item(pos, level40_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level40S then
						minetest.env:add_item(pos, level40S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level41 then
						minetest.env:add_item(pos, level41_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level41S then
						minetest.env:add_item(pos, level41S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level42 then
						minetest.env:add_item(pos, level42_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level42S then
						minetest.env:add_item(pos, level42S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level43 then
						minetest.env:add_item(pos, level43_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level43S then
						minetest.env:add_item(pos, level43S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level44 then
						minetest.env:add_item(pos, level44_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level44S then
						minetest.env:add_item(pos, level44S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level45 then
						minetest.env:add_item(pos, level45_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level45S then
						minetest.env:add_item(pos, level45S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level46 then
						minetest.env:add_item(pos, level46_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level46S then
						minetest.env:add_item(pos, level46S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level47 then
						minetest.env:add_item(pos, level47_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level47S then
						minetest.env:add_item(pos, level47S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level48 then
						minetest.env:add_item(pos, level48_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level48S then
						minetest.env:add_item(pos, level48S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level49 then
						minetest.env:add_item(pos, level49_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level49S then
						minetest.env:add_item(pos, level49S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level50 then
						minetest.env:add_item(pos, level50_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level50S then
						minetest.env:add_item(pos, level50S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level50SS then
						minetest.env:add_item(pos, level50SS_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level51 then
						minetest.env:add_item(pos, level51_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level51S then
						minetest.env:add_item(pos, level51S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level52 then
						minetest.env:add_item(pos, level52_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level52S then
						minetest.env:add_item(pos, level52S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level53 then
						minetest.env:add_item(pos, level53_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level53S then
						minetest.env:add_item(pos, level53S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level54 then
						minetest.env:add_item(pos, level54_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level54S then
						minetest.env:add_item(pos, level54S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level55 then
						minetest.env:add_item(pos, level55_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level55S then
						minetest.env:add_item(pos, level55S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level56 then
						minetest.env:add_item(pos, level56_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level56S then
						minetest.env:add_item(pos, level56S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level57 then
						minetest.env:add_item(pos, level57_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level57S then
						minetest.env:add_item(pos, level57S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level58 then
						minetest.env:add_item(pos, level58_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level58S then
						minetest.env:add_item(pos, level58S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level59 then
						minetest.env:add_item(pos, level59_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level59S then
						minetest.env:add_item(pos, level59S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level60 then
						minetest.env:add_item(pos, level60_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level60S then
						minetest.env:add_item(pos, level60S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level61 then
						minetest.env:add_item(pos, level61_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level61S then
						minetest.env:add_item(pos, level61S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level62 then
						minetest.env:add_item(pos, level62_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level62S then
						minetest.env:add_item(pos, level62S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level63 then
						minetest.env:add_item(pos, level63_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level63S then
						minetest.env:add_item(pos, level63S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level64 then
						minetest.env:add_item(pos, level64_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level64S then
						minetest.env:add_item(pos, level64S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end	
if new_xp == level65 then
						minetest.env:add_item(pos, level65_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level65S then
						minetest.env:add_item(pos, level65S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level66 then
						minetest.env:add_item(pos, level66_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level66S then
						minetest.env:add_item(pos, level66S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level67 then
						minetest.env:add_item(pos, level67_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level67S then
						minetest.env:add_item(pos, level67S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level68 then
						minetest.env:add_item(pos, level68_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level68S then
						minetest.env:add_item(pos, level68S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level69 then
						minetest.env:add_item(pos, level69_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level69S then
						minetest.env:add_item(pos, level69S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level70 then
						minetest.env:add_item(pos, level70_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level70S then
						minetest.env:add_item(pos, level70S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level71 then
						minetest.env:add_item(pos, level71_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level71S then
						minetest.env:add_item(pos, level71S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level72 then
						minetest.env:add_item(pos, level72_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level72S then
						minetest.env:add_item(pos, level72S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level73 then
						minetest.env:add_item(pos, level73_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level73S then
						minetest.env:add_item(pos, level73S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level74 then
						minetest.env:add_item(pos, level74_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level74S then
						minetest.env:add_item(pos, level74S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level75 then
						minetest.env:add_item(pos, level75_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level75S then
						minetest.env:add_item(pos, level75S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level76 then
						minetest.env:add_item(pos, level76_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level76S then
						minetest.env:add_item(pos, level76S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level77 then
						minetest.env:add_item(pos, level77_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level77S then
						minetest.env:add_item(pos, level77S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level78 then
						minetest.env:add_item(pos, level78_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level78S then
						minetest.env:add_item(pos, level78S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level79 then
						minetest.env:add_item(pos, level79_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level79S then
						minetest.env:add_item(pos, level79S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level80 then
						minetest.env:add_item(pos, level80_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level80S then
						minetest.env:add_item(pos, level80S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level81 then
						minetest.env:add_item(pos, level81_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level81S then
						minetest.env:add_item(pos, level81S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level82 then
						minetest.env:add_item(pos, level82_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level82S then
						minetest.env:add_item(pos, level82S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level83 then
						minetest.env:add_item(pos, level83_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level83S then
						minetest.env:add_item(pos, level83S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level84 then
						minetest.env:add_item(pos, level84_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level84S then
						minetest.env:add_item(pos, level84S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level85 then
						minetest.env:add_item(pos, level85_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level85S then
						minetest.env:add_item(pos, level85S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level86 then
						minetest.env:add_item(pos, level86_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level86S then
						minetest.env:add_item(pos, level86S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level87 then
						minetest.env:add_item(pos, level87_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level87S then
						minetest.env:add_item(pos, level87S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level88 then
						minetest.env:add_item(pos, level88_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level88S then
						minetest.env:add_item(pos, level88S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level89 then
						minetest.env:add_item(pos, level89_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level89S then
						minetest.env:add_item(pos, level89S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level90 then
						minetest.env:add_item(pos, level90_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level90S then
						minetest.env:add_item(pos, level90S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level91 then
						minetest.env:add_item(pos, level91_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level91S then
						minetest.env:add_item(pos, level91S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level92 then
						minetest.env:add_item(pos, level92_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level92S then
						minetest.env:add_item(pos, level92S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level93 then
						minetest.env:add_item(pos, level93_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level93S then
						minetest.env:add_item(pos, level93S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level94 then
						minetest.env:add_item(pos, level94_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level94S then
						minetest.env:add_item(pos, level94S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level95 then
						minetest.env:add_item(pos, level95_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level95S then
						minetest.env:add_item(pos, level95S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level96 then
						minetest.env:add_item(pos, level96_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level96S then
						minetest.env:add_item(pos, level96S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level97 then
						minetest.env:add_item(pos, level97_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level97S then
						minetest.env:add_item(pos, level97S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level98 then
						minetest.env:add_item(pos, level98_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level98S then
						minetest.env:add_item(pos, level98S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level99 then
						minetest.env:add_item(pos, level99_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level99S then
						minetest.env:add_item(pos, level99S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level100 then
						minetest.env:add_item(pos, level100_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level100S then
						minetest.env:add_item(pos, level100S_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == level100SS then
						minetest.env:add_item(pos, level100SS_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == levelMAX then
						minetest.env:add_item(pos, levelMAX_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == levelMAXS then
						minetest.env:add_item(pos, levelMAXS_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
if new_xp == levelMAXSS then
						minetest.env:add_item(pos, levelMAXSS_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end

				end
				object:remove()
			end
		end
		for _,object in ipairs(minetest.env:get_objects_inside_radius(pos, 3)) do
			if not object:is_player() and object:get_luaentity() and object:get_luaentity().name == "experience:orb" then
				if object:get_luaentity().collect then
					local pos1 = pos
					pos1.y = pos1.y+0.2
					local pos2 = object:getpos()
					local vec = {x=pos1.x-pos2.x, y=pos1.y-pos2.y, z=pos1.z-pos2.z}
					vec.x = vec.x*3
					vec.y = vec.y*3
					vec.z = vec.z*3
					object:setvelocity(vec)
				end
			end
		end
	end
end)

minetest.register_entity("experience:orb", {
	physical = true,
	timer = 0,
	textures = {"orb.png"},
	visual_size = {x=0.3, y=0.3},
	collisionbox = {-0.17,-0.17,-0.17,0.17,0.17,0.17},
	on_activate = function(self, staticdata)
		self.object:set_armor_groups({immortal=1})
		self.object:setvelocity({x=0, y=1, z=0})
		self.object:setacceleration({x=0, y=-10, z=0})
	end,
	collect = true,
	on_step = function(self, dtime)
		self.timer = self.timer + dtime
		if (self.timer > 300) then
			self.object:remove()
		end
		local p = self.object:getpos()
		local nn = minetest.env:get_node(p).name
		noder = minetest.env:get_node(p).name
		p.y = p.y - 0.3
		local nn = minetest.env:get_node(p).name
		if not minetest.registered_nodes[nn] or minetest.registered_nodes[nn].walkable then
			if self.physical_state then
				self.object:setvelocity({x=0, y=0, z=0})
				self.object:setacceleration({x=0, y=0, z=0})
				self.physical_state = false
				self.object:set_properties({
					physical = false
				})
			end
		else
			if not self.physical_state then
				self.object:setvelocity({x=0,y=0,z=0})
				self.object:setacceleration({x=0, y=-10, z=0})
				self.physical_state = true
				self.object:set_properties({
					physical = true
				})
			end
		end
	end,
})
