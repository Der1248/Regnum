local path = minetest.get_modpath("experience")

dofile(path.."/Xp1_gruen.lua")
dofile(path.."/Xp2_rot.lua")
dofile(path.."/Xp2_blau.lua")
dofile(path.."/Xp3_grau.lua")

