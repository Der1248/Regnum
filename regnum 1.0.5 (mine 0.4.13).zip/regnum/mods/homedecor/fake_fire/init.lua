dofile(minetest.get_modpath("fake_fire").."/modfiles/nodes.lua")
dofile(minetest.get_modpath("fake_fire").."/modfiles/crafts.lua")
dofile(minetest.get_modpath("fake_fire").."/modfiles/abms.lua")
