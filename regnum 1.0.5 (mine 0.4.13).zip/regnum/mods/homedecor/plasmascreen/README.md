PLASMASCREEN
============

Mod adding a plasma screen TV for Minetest.

This mod adds a 2x3 plasma screen TV consisting of 6 nodeboxes.
Code and textures are WTFPL.
