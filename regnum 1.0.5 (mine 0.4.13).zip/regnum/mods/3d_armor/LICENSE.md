3D Armor - Visible Player Armor
===============================

Default Item Textures (C) Cisoun - WTFPL

Armor Textures: Copyright (C) 2013 Ryan Jones - CC-BY-SA

Source Code: Copyright (C) 2013 Stuart Jones - LGPL

Special credit to Jordach and MirceaKitsune for providing the default 3d character model.

