Protector Redo mod [protect]

Protector redo mod for minetest is based on glomie's mod, remade by Zeg9 and reworked by TenPlus1.

https://forum.minetest.net/viewtopic.php?f=11&t=9376

Released under WTFPL

0.1 - Initial release
0.2 - Texture update
0.3 - Added Protection Logo to blend in with player builds
0.4 - Code tweak for 0.4.10+
0.5 - Added protector.radius variable in init.lua (default: 5)
0.6 - Added Protected Doors (wood and steel) and Protected Chest
0.7 - Protected Chests now have "To Chest" and "To Inventory" buttons to copy contents across, also chests can be named
0.8 - Updated to work with Minetest 0.4.12, simplified textures
0.9 - Tweaked code
1.0 - Only owner can remove protector