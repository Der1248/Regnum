minetest-spidermob-v1
=====================

Spider mob extracted from the subgame LOTT
