Technic
=======

License
-------

Copyright (C) 2012-2014 Maciej Kasatkin (RealBadAngel)

Technic chests code is licensed under the GNU LGPLv2+.

Texture licenses:

BlockMen modified by Zefram (CC BY-SA 3.0):
  * technic_chernobylite_block.png
  * technic_corium_flowing_animated.png
  * technic_corium_source_animated.png

celeron55 (Perttu Ahola) modified by Zefram (CC BY-SA 3.0):
  * technic_bucket_corium.png

RealBadAngel: (WTFPL)
  * Everything else.

CC BY-SA 3.0: <http://creativecommons.org/licenses/by-sa/3.0/>
